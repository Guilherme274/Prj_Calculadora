﻿using Prj_Calculadora;
using System;
using System.Reflection.Metadata.Ecma335;
using System.Xml;


Calculadora calculadora = new Calculadora();

int escolha = 0;
float valor1 = 0;
float valor2 = 0;


#region MENU
void ShowMenu()
{

    

    Console.WriteLine("\tMENU ");
    Console.WriteLine(
        "    1 - Adição " + "\n" +
        "    2 - Subtração " + "\n" +
        "    3 - Multiplicação " + "\n" +
        "    4 - Divisão" + "\n" +
        "    5 - Sair");


    Console.Write("\n");


    Console.WriteLine("Escolha uma opção: ");



    if (int.TryParse(Console.ReadLine(), out escolha))
    {
        Escolha();

    }
    else
    {

        Console.Write("\n");

        Console.WriteLine("Devem ser digitados apenas os números contidos no Menu");

        Console.Write("\n");

        ShowMenu();
    }


     


}
#endregion

#region Escolha do Usuário
void Escolha()
{

    switch (escolha)
    {

        case 1:

            if (Digitar() == false)
            {
                Console.Write("\n");

                Console.WriteLine("Devem ser digitados apenas os números contidos no Menu");

                Console.Write("\n");

                ShowMenu();
            }
            else
            {
                calculadora.CalcularAdicao(valor1, valor2);

                ShowMenu();
            }


            break;

        case 2:

            if (Digitar() == false)
            {
                Console.Write("\n");

                Console.WriteLine("Devem ser digitados apenas os números contidos no Menu");

                Console.Write("\n");

                ShowMenu();
            }
            else
            {
                
                calculadora.CalcularSubtracao(valor1, valor2);

                ShowMenu();
            }



            break;

        case 3:


            if (Digitar() == false)
            {
                Console.Write("\n");

                Console.WriteLine("Devem ser digitados apenas os números contidos no Menu");

                Console.Write("\n");

                ShowMenu();
            }
            else
            {
                calculadora.CalcularMultiplicacao(valor1, valor2);

                ShowMenu();
            }


            break;

        case 4:


            if (Digitar() == false)
            {
                Console.Write("\n");

                Console.WriteLine("Devem ser digitados apenas os números contidos no Menu");

                Console.Write("\n");

                ShowMenu();
            }
            else
            {
                if (valor2 == 0)
                {
                    Console.Write("\n");

                    Console.WriteLine("Não é possível divisões por 0");

                    Console.Write("\n");

                    ShowMenu();
                }
                else
                {
                    calculadora.CalcularDivisao(valor1, valor2);

                    ShowMenu();
                }
            }



            break;

        case 5:

            Console.Write("\n");

            Console.WriteLine("OBRIGADO POR TESTAR!!! ");

            break;

        default:

            Console.Write("\n");

            Console.WriteLine("Devem ser digitados apenas os números contidos no Menu");

            Console.Write("\n");

            ShowMenu();
            break;
    }
}

#endregion

#region Digitação dos Valores


bool Digitar()
{

    bool Primeiro()
    {



        Console.Write("\n");

        Console.WriteLine("Digite o primeiro número: ");

        if (float.TryParse(Console.ReadLine(), out valor1))
        {
            return true;
        }
        else
        {

            return false;
        }

    }



    bool Segundo()
    {
        Console.Write("\n");

        Console.WriteLine("Digite o segundo número: ");


        if (float.TryParse(Console.ReadLine(), out valor2))
        {
            return true;
        }
        else
        {

            return false;
        }


    }

    while (Primeiro() == false || Segundo() == false)
    {
        return false;
    }
    return true;

}

#endregion

Console.WriteLine(" BEM VINDO(A) AO PROGRAMA DE OPERAÇÕES MATEMÁTICAS ");

Console.Write("\n");

ShowMenu();








