﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;


namespace Prj_Calculadora
{
    public class Calculadora
    {

        public void CalcularAdicao(float valor1, float valor2)
        {
            Console.Write("\n");

            Console.WriteLine("A soma desses valores é: " + (valor1 + valor2));

            Console.Write("\n");

        }




        public void CalcularSubtracao(float valor1, float valor2)
        {
            Console.Write("\n");

            Console.WriteLine("A subtração desses valores é: " + (valor1 - valor2));

            Console.Write("\n");

        }





        public void CalcularDivisao(float valor1, float valor2)
        {


            Console.Write("\n");

            Console.WriteLine("A divisão desses valores é: " + (valor1 / valor2));

            Console.Write("\n");

        }





        public void CalcularMultiplicacao(float valor1, float valor2)
        {
            Console.Write("\n");

            Console.WriteLine("A multiplicação desses valores é: " + (valor1 * valor2));

            Console.Write("\n");

        }


    }
}



